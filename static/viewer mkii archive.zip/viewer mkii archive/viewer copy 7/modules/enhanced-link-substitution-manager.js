/**
 * Enhanced Link Substitution Manager
 * Downloads linked content, substitutes it in place, and highlights broken links
 */

export class EnhancedLinkSubstitutionManager {
  constructor(documentLoader, jsonldProcessor, referenceManager, jsonRenderer) {
    this.documentLoader = documentLoader;
    this.jsonldProcessor = jsonldProcessor;
    this.referenceManager = referenceManager;
    this.jsonRenderer = jsonRenderer;
    
    // Track link status
    this.linkStatus = new Map(); // url -> { status: 'loading'|'success'|'error', data?: any, error?: string }
    this.substitutionCache = new Map();
    
    // Configuration
    this.maxDepth = 2;
    this.enabled = true;
    this.skipPatterns = ['#', 'javascript:', 'mailto:'];
  }

  /**
   * Main method: Process document and substitute all linked entries
   */
  async processDocumentWithSubstitution(document, options = {}) {
    const {
      maxDepth = 2,
      skipBrokenLinks = true,
      showProgress = true
    } = options;

    this.maxDepth = maxDepth;
    
    if (!this.enabled) {
      return document;
    }

    console.log('🔄 Starting enhanced link substitution...');
    
    try {
      // Deep clone to avoid mutating original
      const processedDocument = JSON.parse(JSON.stringify(document));
      
      // Find and process all linked entries
      await this.processLinkedEntries(processedDocument, 0);
      
      console.log('✅ Enhanced link substitution completed');
      return processedDocument;
      
    } catch (error) {
      console.error('❌ Enhanced link substitution failed:', error);
      throw error;
    }
  }

  /**
   * Recursively process linked entries in the document
   */
  async processLinkedEntries(obj, depth = 0, path = []) {
    if (depth >= this.maxDepth || !obj || typeof obj !== 'object') {
      return obj;
    }

    if (Array.isArray(obj)) {
      // Process array items
      for (let i = 0; i < obj.length; i++) {
        const item = obj[i];
        const newPath = [...path, i];
        
        if (this.isLinkToSubstitute(item)) {
          const substituted = await this.substituteLink(item, depth + 1, newPath);
          obj[i] = substituted;
        } else if (typeof item === 'object') {
          await this.processLinkedEntries(item, depth, newPath);
        }
      }
    } else {
      // Process object properties
      for (const [key, value] of Object.entries(obj)) {
        const newPath = [...path, key];
        
        if (this.isLinkToSubstitute(value, key)) {
          const substituted = await this.substituteLink(value, depth + 1, newPath, key);
          obj[key] = substituted;
        } else if (typeof value === 'object') {
          await this.processLinkedEntries(value, depth, newPath);
        }
      }
    }

    return obj;
  }

  /**
   * Check if a value should be substituted with linked content
   */
  isLinkToSubstitute(value, key = null) {
    // Simple @id object: {"@id": "url"}
    if (typeof value === 'object' && value !== null && !Array.isArray(value) &&
        Object.keys(value).length === 1 && value['@id'] && typeof value['@id'] === 'string') {
      return this.isValidUrl(value['@id']);
    }

    // String value in known linked property
    if (typeof value === 'string' && key) {
      const isLinkedProp = this.referenceManager?.isLinkedProperty(key) || 
                          this.isKnownLinkProperty(key);
      return isLinkedProp && this.isValidUrl(value);
    }

    return false;
  }

  /**
   * Check if a property is a known link property
   */
  isKnownLinkProperty(key) {
    const linkProperties = [
      '@id', 'id', 'identifier', 'url', 'href', 'link', 'reference',
      'sameAs', 'seeAlso', 'isDefinedBy', 'rdfs:seeAlso', 'owl:sameAs'
    ];
    return linkProperties.includes(key) || 
           key.endsWith('Id') || 
           key.endsWith('_id') || 
           key.includes('link') || 
           key.includes('ref');
  }

  /**
   * Check if URL is valid and should be processed
   */
  isValidUrl(url) {
    if (!url || typeof url !== 'string') return false;
    
    // Skip certain patterns
    if (this.skipPatterns.some(pattern => url.includes(pattern))) return false;
    
    // Must be HTTP/HTTPS
    return url.startsWith('http://') || url.startsWith('https://');
  }

  /**
   * Substitute a link with its downloaded content
   */
  async substituteLink(linkValue, depth, path, key = null) {
    let url;
    let originalStructure = linkValue;

    // Extract URL from different structures
    if (typeof linkValue === 'object' && linkValue['@id']) {
      url = linkValue['@id'];
    } else if (typeof linkValue === 'string') {
      url = linkValue;
    } else {
      return linkValue; // Can't process
    }

    // Resolve URL if needed
    const resolvedUrl = this.referenceManager?.expandReference(url, key) || url;
    
    console.log(`🔗 Processing link: ${url} -> ${resolvedUrl}`);

    // Check if already processed
    if (this.linkStatus.has(resolvedUrl)) {
      const status = this.linkStatus.get(resolvedUrl);
      return this.createSubstitutionResult(originalStructure, url, resolvedUrl, status);
    }

    // Mark as loading
    this.linkStatus.set(resolvedUrl, { status: 'loading' });

    try {
      // Download content
      const content = await this.downloadLinkContent(resolvedUrl);
      
      if (content) {
        // Process the downloaded content recursively if within depth limit
        let processedContent = content;
        if (depth < this.maxDepth) {
          processedContent = await this.processLinkedEntries(content, depth);
        }

        // Store success
        const successStatus = { 
          status: 'success', 
          data: processedContent,
          timestamp: Date.now(),
          originalUrl: url,
          resolvedUrl: resolvedUrl
        };
        this.linkStatus.set(resolvedUrl, successStatus);

        return this.createSubstitutionResult(originalStructure, url, resolvedUrl, successStatus);
        
      } else {
        throw new Error('No content received');
      }

    } catch (error) {
      console.warn(`⚠️ Failed to substitute link ${resolvedUrl}:`, error.message);
      
      // Store error
      const errorStatus = { 
        status: 'error', 
        error: error.message,
        timestamp: Date.now(),
        originalUrl: url,
        resolvedUrl: resolvedUrl
      };
      this.linkStatus.set(resolvedUrl, errorStatus);

      return this.createSubstitutionResult(originalStructure, url, resolvedUrl, errorStatus);
    }
  }

  /**
   * Download and process link content
   */
  async downloadLinkContent(url) {
    // Check cache first
    if (this.substitutionCache.has(url)) {
      console.log(`📋 Using cached content for: ${url}`);
      return this.substitutionCache.get(url);
    }

    try {
      console.log(`📥 Downloading link content: ${url}`);
      const rawContent = await this.documentLoader.fetchDocument(url);
      
      if (!rawContent) {
        throw new Error('Empty response');
      }

      // Process JSON-LD if applicable
      let processedContent = rawContent;
      if (this.isJsonLd(rawContent)) {
        try {
          processedContent = await this.jsonldProcessor.expand(rawContent);
          
          // Extract main entity if it's an array
          if (Array.isArray(processedContent) && processedContent.length > 0) {
            // Find entity with matching @id or use first one
            const mainEntity = processedContent.find(item => item['@id'] === url) || 
                              processedContent[0];
            processedContent = mainEntity;
          }
        } catch (jsonLdError) {
          console.warn(`⚠️ JSON-LD processing failed for ${url}, using raw content:`, jsonLdError.message);
        }
      }

      // Cache the result
      this.substitutionCache.set(url, processedContent);
      
      return processedContent;
      
    } catch (error) {
      console.error(`❌ Failed to download ${url}:`, error);
      throw error;
    }
  }

  /**
   * Create the substitution result based on status
   */
  createSubstitutionResult(originalStructure, originalUrl, resolvedUrl, status) {
    const baseResult = {
      '@id': originalUrl,
      '@resolved': true,
      '@status': status.status,
      '@timestamp': status.timestamp || Date.now()
    };

    if (resolvedUrl !== originalUrl) {
      baseResult['@resolvedUrl'] = resolvedUrl;
    }

    switch (status.status) {
      case 'success':
        return {
          ...baseResult,
          ...status.data, // Merge the actual content
          '@substituted': true
        };

      case 'error':
        return {
          ...baseResult,
          '@error': status.error,
          '@broken': true,
          // Preserve original structure for display
          ...(typeof originalStructure === 'object' ? originalStructure : {})
        };

      case 'loading':
        return {
          ...baseResult,
          '@loading': true,
          // Preserve original structure for display
          ...(typeof originalStructure === 'object' ? originalStructure : {})
        };

      default:
        return originalStructure;
    }
  }

  /**
   * Check if content is JSON-LD
   */
  isJsonLd(content) {
    if (!content || typeof content !== 'object') return false;
    
    return !!(
      content['@context'] ||
      content['@id'] ||
      content['@type'] ||
      content['@graph'] ||
      (Array.isArray(content) && content.some(item => 
        item && typeof item === 'object' && (item['@context'] || item['@id'] || item['@type'])
      ))
    );
  }

  /**
   * Get statistics about link processing
   */
  getLinkStats() {
    const stats = {
      total: this.linkStatus.size,
      success: 0,
      error: 0,
      loading: 0,
      urls: {
        success: [],
        error: [],
        loading: []
      }
    };

    for (const [url, status] of this.linkStatus.entries()) {
      stats[status.status]++;
      stats.urls[status.status].push(url);
    }

    return stats;
  }

  /**
   * Clear all caches and reset state
   */
  clearAll() {
    this.linkStatus.clear();
    this.substitutionCache.clear();
    console.log('🧹 Link substitution caches cleared');
  }

  /**
   * Enable/disable link substitution
   */
  setEnabled(enabled) {
    this.enabled = enabled;
  }

  /**
   * Set maximum substitution depth
   */
  setMaxDepth(depth) {
    this.maxDepth = Math.max(1, Math.min(5, depth));
  }
}
