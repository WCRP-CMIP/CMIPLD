// Simple module validation script
// This can be run in the browser console to verify modules are loading correctly

console.log('🔍 Testing CMIP-LD Viewer Module Architecture...');

// Test module factory
import { ModuleFactory } from './modules/core/module-factory.js';

// Mock viewer object for testing
const mockViewer = {
  rerenderDisplay: () => console.log('✅ rerenderDisplay callback works'),
  handleFieldExpansion: (field, expand) => console.log(`✅ handleFieldExpansion callback works: ${field}, ${expand}`)
};

try {
  // Test module creation
  console.log('📦 Creating modules...');
  const modules = ModuleFactory.createModules(mockViewer);
  
  // Verify all expected modules exist
  const expectedModules = [
    'stateManager',
    'documentLoader', 
    'referenceManager',
    'jsonldProcessor',
    'jsonRenderer',
    'contextResolutionManager',
    'linkedDocumentManager',
    'viewManager',
    'exportManager',
    'uiManager',
    'displayManager',
    'eventManager',
    'initializationManager',
    'dataLoadingManager',
    'workflowManager'
  ];
  
  console.log('🔍 Checking module creation...');
  for (const moduleName of expectedModules) {
    if (modules[moduleName]) {
      console.log(`✅ ${moduleName} created successfully`);
    } else {
      console.error(`❌ ${moduleName} missing!`);
    }
  }
  
  // Test module relationships
  console.log('🔗 Configuring module relationships...');
  ModuleFactory.configureModuleRelationships(modules, mockViewer);
  
  // Test a simple method call
  if (modules.stateManager.initializeState) {
    console.log('✅ StateManager methods accessible');
  }
  
  if (modules.initializationManager.shouldAutoLoad) {
    console.log('✅ InitializationManager methods accessible');
  }
  
  console.log('🎉 Module architecture validation completed successfully!');
  console.log(`📊 Created ${Object.keys(modules).length} modules`);
  
} catch (error) {
  console.error('❌ Module validation failed:', error);
}
