// Test the ID link resolution functionality
// This script can be loaded in the browser console to test the changes

console.log('🔍 Testing ID Link Resolution...');

// Test data with various ID patterns
const testData = {
  "@id": "universal:activity/cmip",
  "id": "model-123",
  "hasParent": {"@id": "universal:parent/test"},
  "relatedItems": [
    {"@id": "https://example.com/item1"},
    {"@id": "cmip6plus:source/model"},
    "simple-string"
  ],
  "nested": {
    "subId": "cf:variable/temperature",
    "url": "https://direct.url.com/resource"
  }
};

// Mock prefix mapping for testing
const testPrefixMapping = {
  'universal': 'https://wcrp-cmip.github.io/WCRP-universe/',
  'cmip6plus': 'https://wcrp-cmip.github.io/CMIP6Plus_CVs/',
  'cf': 'https://wcrp-cmip.github.io/CF/'
};

// Mock context for testing
const testContext = {
  '@base': 'https://example.com/',
  'hasParent': {'@type': '@id'},
  'relatedItems': {'@type': '@id'},
  'universal': 'https://wcrp-cmip.github.io/WCRP-universe/',
  'cmip6plus': 'https://wcrp-cmip.github.io/CMIP6Plus_CVs/',
  'cf': 'https://wcrp-cmip.github.io/CF/'
};

try {
  // Import the modules we need
  import('./modules/reference-manager.js').then(({ ReferenceManager }) => {
    import('./modules/json-renderer.js').then(({ JSONRenderer }) => {
      
      console.log('📦 Modules loaded successfully');
      
      // Create reference manager and configure it
      const referenceManager = new ReferenceManager(testPrefixMapping);
      referenceManager.setResolvedContext(testContext);
      
      // Create JSON renderer and configure it
      const jsonRenderer = new JSONRenderer();
      jsonRenderer.setReferenceManager(referenceManager);
      
      console.log('⚙️ Components configured');
      
      // Test ID resolution for different types
      const testCases = [
        { value: 'universal:activity/cmip', key: '@id', expected: 'https://wcrp-cmip.github.io/WCRP-universe/activity/cmip' },
        { value: 'cmip6plus:source/model', key: 'id', expected: 'https://wcrp-cmip.github.io/CMIP6Plus_CVs/source/model' },
        { value: 'cf:variable/temperature', key: 'subId', expected: 'https://wcrp-cmip.github.io/CF/variable/temperature' },
        { value: 'https://direct.url.com/resource', key: 'url', expected: 'https://direct.url.com/resource' },
        { value: 'model-123', key: 'id', expected: 'https://example.com/model-123' }  // Should use @base
      ];
      
      console.log('🧪 Running resolution tests...');
      
      testCases.forEach((testCase, index) => {
        const resolved = jsonRenderer.resolveUrl(testCase.value, testCase.key);
        const passed = resolved === testCase.expected;
        
        console.log(`Test ${index + 1}: ${passed ? '✅' : '❌'}`);
        console.log(`  Input: ${testCase.value} (key: ${testCase.key})`);
        console.log(`  Expected: ${testCase.expected}`);
        console.log(`  Got: ${resolved}`);
        
        if (!passed) {
          console.warn(`  🔍 Test failed - check resolution logic`);
        }
      });
      
      // Test rendering a small object to see if links are created
      console.log('🎨 Testing link rendering...');
      
      const testElement = document.createElement('div');
      testElement.id = 'test-json-output';
      document.body.appendChild(testElement);
      
      jsonRenderer.renderJson(testData, testElement);
      
      // Count the created links
      const links = testElement.querySelectorAll('a.json-url');
      console.log(`✅ Created ${links.length} clickable links in rendered JSON`);
      
      // Log the hrefs to verify they're correctly resolved
      links.forEach((link, index) => {
        console.log(`  Link ${index + 1}: ${link.textContent} -> ${link.href}`);
      });
      
      console.log('🎉 ID Link Resolution test completed!');
      
    }).catch(error => {
      console.error('❌ Failed to load JSONRenderer:', error);
    });
  }).catch(error => {
    console.error('❌ Failed to load ReferenceManager:', error);  
  });
} catch (error) {
  console.error('❌ Test setup failed:', error);
}
