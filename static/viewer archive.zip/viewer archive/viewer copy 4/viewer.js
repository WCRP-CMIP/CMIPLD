// Main CMIP-LD Viewer class that orchestrates all modules
import { CONFIG } from './modules/config.js';
import { Utils } from './modules/utils.js';
import { URLManager } from './modules/url-manager.js';
import { DocumentLoader } from './modules/document-loader.js';
import { ReferenceManager } from './modules/reference-manager.js';
import { JSONLDProcessor } from './modules/jsonld-processor.js';
import { LinkedItemResolver } from './modules/linked-item-resolver.js';
import { ContextExpander } from './modules/context-expander.js';
import { JSONRenderer } from './modules/json-renderer.js';
import { UIManager } from './modules/ui-manager.js';

export class CMIPLDViewer {
  constructor() {
    this.initializeModules();
    this.initializeState();
    this.initializeFromUrl();
    this.initializeEventListeners();
  }

  initializeModules() {
    // Core modules
    this.documentLoader = new DocumentLoader(CONFIG.corsProxies);
    this.referenceManager = new ReferenceManager(CONFIG.prefixMapping);
    this.jsonldProcessor = new JSONLDProcessor(this.documentLoader, {});
    this.linkedItemResolver = new LinkedItemResolver(this.referenceManager, this.jsonldProcessor, CONFIG.prefixMapping);
    this.contextExpander = new ContextExpander(this.documentLoader, CONFIG.prefixMapping);
    this.jsonRenderer = new JSONRenderer();
    this.jsonRenderer.setReferenceManager(this.referenceManager);
    this.uiManager = new UIManager(this.jsonRenderer, this.referenceManager);
    
    // Connect UI callbacks
    this.uiManager.triggerRerender = () => this.rerenderDisplay();
    this.uiManager.triggerFieldExpansion = (field, expand) => this.handleFieldExpansion(field, expand);
  }

  initializeState() {
    this.currentRawData = null;
    this.currentProcessedData = null;
    this.resolvedContext = {};
    this.isExpanded = false;
  }

  initializeFromUrl() {
    const settings = URLManager.initializeFromUrl();
    
    // Apply settings to DOM
    if (settings.uri) {
      document.getElementById('uri').value = settings.uri;
    }
    if (settings.depth) {
      document.getElementById('depth').value = settings.depth;
    } else {
      document.getElementById('depth').value = CONFIG.defaults.depth;
    }
    if (settings.followLinks !== undefined) {
      document.getElementById('followLinks').checked = settings.followLinks;
    } else {
      document.getElementById('followLinks').checked = CONFIG.defaults.followLinks;
    }
    if (settings.insertContext !== undefined) {
      document.getElementById('insertContext').checked = settings.insertContext;
    } else {
      document.getElementById('insertContext').checked = CONFIG.defaults.insertContext;
    }
    
    this.isExpanded = settings.isExpanded || false;
    document.getElementById('viewToggle').checked = this.isExpanded;
    
    // Apply panel state
    if (settings.panelMinimized) {
      const inputSection = document.getElementById('inputSection');
      const minimizeIcon = document.querySelector('.minimize-icon');
      inputSection.classList.add('minimized');
      minimizeIcon.textContent = '+';
      document.getElementById('minimizeBtn').title = 'Expand';
    }
    
    console.log('Initialized from URL - isExpanded:', this.isExpanded);
    
    // Auto-load if URI is provided
    if (settings.uri) {
      setTimeout(() => this.loadData(), 100);
    }
  }

  initializeEventListeners() {
    // Basic controls
    document.getElementById('loadBtn').addEventListener('click', () => this.loadData());
    document.getElementById('uri').addEventListener('keypress', (e) => {
      if (e.key === 'Enter') this.loadData();
    });
    
    // Minimize button
    this.initializeMinimizeButton();
    
    // Settings changes
    document.getElementById('uri').addEventListener('input', () => this.updateUrl());
    document.getElementById('depth').addEventListener('change', () => this.updateUrl());
    document.getElementById('followLinks').addEventListener('change', () => this.updateUrl());
    document.getElementById('insertContext').addEventListener('change', () => {
      this.updateUrl();
      this.updateView();
    });
    
    // Export functions
    document.getElementById('copyBtn').addEventListener('click', () => this.copyToClipboard());
    document.getElementById('downloadBtn').addEventListener('click', () => this.downloadJson());
    
    // View toggle
    this.initializeViewToggle();
  }

  initializeMinimizeButton() {
    const minimizeBtn = document.getElementById('minimizeBtn');
    const inputSection = document.getElementById('inputSection');
    const minimizeIcon = minimizeBtn.querySelector('.minimize-icon');
    
    minimizeBtn.addEventListener('click', () => {
      inputSection.classList.toggle('minimized');
      
      // Update icon
      if (inputSection.classList.contains('minimized')) {
        minimizeIcon.textContent = '+';
        minimizeBtn.title = 'Expand';
      } else {
        minimizeIcon.textContent = '−';
        minimizeBtn.title = 'Minimize';
      }
      
      // Update URL
      this.updateUrl();
    });
  }

  initializeViewToggle() {
    const viewToggle = document.getElementById('viewToggle');
    
    const handleToggle = (checked) => {
      console.log('🔄 Toggle change:', checked);
      this.isExpanded = checked;
      this.updateUrl();
      
      if (this.currentRawData) {
        this.updateView();
      }
    };
    
    viewToggle.addEventListener('change', (e) => handleToggle(e.target.checked));
    viewToggle.addEventListener('click', (e) => {
      setTimeout(() => handleToggle(e.target.checked), 10);
    });
    viewToggle.addEventListener('input', (e) => handleToggle(e.target.checked));
  }

  updateUrl() {
    const inputSection = document.getElementById('inputSection');
    const settings = {
      uri: document.getElementById('uri').value.trim(),
      depth: document.getElementById('depth').value,
      followLinks: document.getElementById('followLinks').checked,
      insertContext: document.getElementById('insertContext').checked,
      isExpanded: this.isExpanded,
      panelMinimized: inputSection.classList.contains('minimized')
    };
    
    URLManager.updateUrl(settings);
  }

  async loadData() {
    const uri = document.getElementById('uri').value.trim();
    if (!uri) {
      this.uiManager.showError('Please enter a URI or prefix');
      return;
    }

    const depth = parseInt(document.getElementById('depth').value) || 2;
    
    this.uiManager.showLoading(true);

    try {
      // Clear previous data
      this.clearData();
      
      this.updateUrl();
      
      // Step 1: Load main document
      const resolvedUri = Utils.resolvePrefix(uri, CONFIG.prefixMapping);
      const data = await this.documentLoader.fetchDocument(resolvedUri);
      this.currentRawData = data;
      
      console.log('📊 Loaded raw data, keys:', Object.keys(data));
      
      // Extract base URL from context if available
      let baseUrl = resolvedUri;
      if (data['@context']) {
        const extractedBase = this.extractBaseFromContext(data['@context']);
        if (extractedBase) {
          baseUrl = extractedBase;
          console.log('🔗 Extracted base URL from @context:', baseUrl);
        }
      }
      
      // Step 2: Load linked documents
      await this.loadLinkedDocuments(data, baseUrl, depth);
      
      // Step 3: Build resolved context
      this.resolvedContext = await this.documentLoader.buildResolvedContext(data, baseUrl);
      console.log('📝 Raw resolved context:', this.resolvedContext);
      this.jsonldProcessor.resolvedContext = this.resolvedContext;
      this.referenceManager.setResolvedContext(this.resolvedContext);
      console.log('📝 Built context with', Object.keys(this.resolvedContext).length, 'terms');
      
      // Step 4: Index all entities
      await this.jsonldProcessor.indexAllEntities(this.documentLoader.loadedDocuments);
      
      // Step 5: Process and display
      this.currentProcessedData = await this.processData();
      this.displayResult(this.currentProcessedData);
      
    } catch (error) {
      this.uiManager.showError(`Failed to load data: ${error.message}`);
    } finally {
      this.uiManager.showLoading(false);
    }
  }

  async loadLinkedDocuments(data, baseUrl, depth) {
    if (depth <= 0) return;

    const followLinks = document.getElementById('followLinks').checked;
    if (!followLinks) {
      console.log('🔗 Follow Links disabled - skipping linked document loading');
      return;
    }

    console.log(`🔗 Loading linked documents at depth ${depth}`);
    
    // First, expand the data to find all @id references
    let expandedData;
    try {
      expandedData = await this.jsonldProcessor.safeExpand(data);
      console.log('🔗 Expanded data for reference collection');
    } catch (error) {
      console.warn('⚠️ Could not expand data for reference collection:', error);
      expandedData = data;
    }
    
    // Collect all @id references from the expanded data
    const refs = new Set();
    this.collectExpandedReferences(expandedData, refs);
    
    // Also collect from original data using the reference manager
    const originalRefs = this.referenceManager.collectIdReferences(data);
    originalRefs.forEach(ref => refs.add(ref));
    
    console.log(`🔗 Found ${refs.size} total references to load`);
    if (refs.size > 0) {
      console.log('🔗 References:', Array.from(refs));
    }
    
    const loadedUrls = new Set();
    
    for (const ref of refs) {
      let resolvedRef = Utils.resolvePrefix(ref, CONFIG.prefixMapping);
      
      if (!resolvedRef.startsWith('http')) {
        resolvedRef = Utils.resolveUrl(resolvedRef, baseUrl);
      }

      if (loadedUrls.has(resolvedRef)) continue;
      loadedUrls.add(resolvedRef);

      try {
        console.log(`🔗 Loading linked document: ${resolvedRef}`);
        const linkedDoc = await this.documentLoader.fetchDocument(resolvedRef);
        
        if (depth > 1 && linkedDoc) {
          await this.loadLinkedDocuments(linkedDoc, resolvedRef, depth - 1);
        }
      } catch (error) {
        console.warn(`Could not load linked document ${resolvedRef}:`, error.message);
      }
    }
  }

  // Collect @id references from expanded JSON-LD data
  collectExpandedReferences(data, refs, visited = new Set()) {
    if (!data || visited.has(data)) return;
    
    if (typeof data === 'object') {
      visited.add(data);
      
      if (Array.isArray(data)) {
        data.forEach(item => this.collectExpandedReferences(item, refs, visited));
      } else {
        // Check for @id values
        if (data['@id'] && typeof data['@id'] === 'string') {
          // Only add if this looks like a reference we should load
          if (Object.keys(data).length === 1 || 
              (Object.keys(data).length === 2 && data['@type'])) {
            refs.add(data['@id']);
          }
        }
        
        // Recursively check all values
        Object.values(data).forEach(value => {
          this.collectExpandedReferences(value, refs, visited);
        });
      }
      
      visited.delete(data);
    }
  }

  async processData() {
    if (!this.currentRawData) return null;

    console.log('🔄 === PROCESSING DATA ===');
    console.log('📋 isExpanded:', this.isExpanded);

    try {
      // Step 1: JSON-LD expansion
      console.log('🔄 Step 1: Expanding JSON-LD document...');
      let expandedData = await this.jsonldProcessor.safeExpand(this.currentRawData);
      console.log('✅ Initial expansion complete');
      
      // Step 2: Iterative @id resolution
      const depth = parseInt(document.getElementById('depth').value) || 2;
      console.log(`🔄 Step 2: Iteratively inserting linked items (depth: ${depth})...`);
      let resolvedData = this.linkedItemResolver.iterativelyInsertLinkedItems(expandedData, depth);
      console.log('✅ Iterative @id resolution complete');
      
      // Step 3: Handle output format
      if (this.isExpanded) {
        console.log('📋 Returning expanded format');
        
        // Step 4: Handle context insertion for expanded view
        const insertContext = document.getElementById('insertContext').checked;
        if (insertContext && Object.keys(this.resolvedContext).length > 0) {
          // Insert context into expanded data
          if (Array.isArray(resolvedData) && resolvedData.length > 0) {
            // For array format, we need to wrap in an object
            resolvedData = {
              '@context': this.resolvedContext,
              '@graph': resolvedData
            };
            console.log('📝 Inserted resolved context into expanded view (using @graph)');
          } else if (typeof resolvedData === 'object' && !Array.isArray(resolvedData)) {
            // For single object, add context directly
            resolvedData = {
              '@context': this.resolvedContext,
              ...resolvedData
            };
            console.log('📝 Inserted resolved context into expanded view');
          }
        } else {
          console.log('📝 Context not inserted - Insert Context checkbox not checked');
        }
        
        return resolvedData;
      } else {
        console.log('📄 Step 3: Compacting to human-readable format...');
        
        let compactedData;
        const insertContext = document.getElementById('insertContext').checked;
        
        // Always use the best available context for compaction to get readable keys
        let compactionContext;
        if (Object.keys(this.resolvedContext).length > 0) {
          // Prefer resolved context as it's the most complete
          compactionContext = this.resolvedContext;
        } else if (this.currentRawData['@context']) {
          // Fall back to original document's context
          compactionContext = this.currentRawData['@context'];
        } else {
          // If no context available, use empty object
          compactionContext = {};
        }
        
        console.log('🔄 Using context for compaction (to get readable keys)');
        compactedData = await this.jsonldProcessor.safeCompact(resolvedData, compactionContext);
        
        // Ensure linked fields are present and resolved
        compactedData = this.ensureLinkedFieldsPresent(compactedData, resolvedData);
        
        // Step 4: Handle context insertion
        if (insertContext && Object.keys(this.resolvedContext).length > 0) {
          // Only insert context if checkbox is checked
          if (typeof compactedData === 'object' && !Array.isArray(compactedData)) {
            // Remove any existing context first
            const { '@context': existingContext, ...dataWithoutContext } = compactedData;
            compactedData = {
              '@context': this.resolvedContext,
              ...dataWithoutContext
            };
            console.log('📝 Inserted resolved context');
          }
          
          compactedData = this.contextExpander.expandContextReferences(compactedData, insertContext);
        } else {
          // Remove context if checkbox is not checked
          if (typeof compactedData === 'object' && !Array.isArray(compactedData) && compactedData['@context']) {
            const { '@context': removedContext, ...dataWithoutContext } = compactedData;
            compactedData = dataWithoutContext;
            console.log('📝 Context removed - Insert Context checkbox not checked');
          } else {
            console.log('📝 Context not inserted - Insert Context checkbox not checked');
          }
        }
        
        console.log('✅ Compaction complete');
        return compactedData;
      }
    } catch (error) {
      console.error('❌ Data processing failed:', error);
      return this.currentRawData;
    }
  }

  async updateView() {
    if (!this.currentRawData) {
      console.log('⚠️  No raw data available for view update');
      return;
    }

    console.log('🔄 === UPDATING VIEW ===');

    const toggleContainer = document.querySelector('.result-header');
    if (toggleContainer) {
      toggleContainer.style.opacity = '0.6';
    }

    try {
      this.jsonRenderer.clearHiddenFields();
      this.currentProcessedData = await this.processData();
      this.displayResult(this.currentProcessedData);
      
      console.log('✅ === VIEW UPDATE COMPLETE ===');
    } catch (error) {
      console.error('❌ Failed to update view:', error);
      this.uiManager.showError(`Failed to update view: ${error.message}`);
    } finally {
      if (toggleContainer) {
        toggleContainer.style.opacity = '1';
      }
    }
  }

  displayResult(data) {
    const resultSection = document.getElementById('resultSection');
    const statsElement = document.getElementById('resultStats');
    const jsonViewer = document.getElementById('jsonViewer');
    const viewToggle = document.getElementById('viewToggle');
    
    viewToggle.checked = this.isExpanded;
    
    // Calculate statistics
    const displayData = this.jsonRenderer.filterHiddenFields(data);
    console.log('📋 Data structure:', {
      isArray: Array.isArray(data),
      hasGraph: data['@graph'] !== undefined,
      topLevelKeys: Object.keys(data),
      sampleData: JSON.stringify(data, null, 2).substring(0, 500) + '...'
    });
    const jsonString = JSON.stringify(displayData, null, 2);
    const lines = jsonString.split('\n').length;
    const size = new Blob([jsonString]).size;
    const loadedUrls = this.documentLoader.loadedDocuments.size;
    const indexedEntities = this.jsonldProcessor.entityIndex.size;
    const contextKeys = Object.keys(this.resolvedContext).length;
    const contextDocs = this.documentLoader.contextDocuments.size;
    
    const viewMode = this.isExpanded ? 
      '📋 Expanded JSON-LD (jsonld.expand output - absolute URIs)' : 
      '📄 Compacted JSON-LD (human-readable with context)';
    
    statsElement.textContent = `${viewMode} • ${lines} lines • ${Utils.formatBytes(size)} • ${loadedUrls} documents • ${indexedEntities} entities • ${contextKeys} context terms • ${contextDocs} context docs`;
    
    // Create field toggles - pass the processed data for field detection
    console.log('📋 Creating field toggles, data keys:', Object.keys(data));
    this.uiManager.createFieldToggles(data, this.resolvedContext);
    
    // Render JSON
    this.jsonRenderer.renderJson(displayData, jsonViewer);
    
    resultSection.style.display = 'block';
    resultSection.scrollIntoView({ behavior: 'smooth' });
  }

  // UI callback handlers
  rerenderDisplay() {
    if (this.currentProcessedData) {
      const jsonViewer = document.getElementById('jsonViewer');
      const displayData = this.jsonRenderer.filterHiddenFields(this.currentProcessedData);
      this.jsonRenderer.renderJson(displayData, jsonViewer);
    }
  }

  handleFieldExpansion(field, expand) {
    if (!this.currentProcessedData) return;
    
    if (expand) {
      // Force expand field logic would go here
      console.log(`🔗 Force expanding field: ${field}`);
    } else {
      // Revert expansion
      console.log(`🔗 Reverting field expansion: ${field}`);
    }
    
    this.rerenderDisplay();
  }

  // Extract base URL from context
  extractBaseFromContext(context) {
    if (!context) return null;
    
    // Handle array of contexts
    if (Array.isArray(context)) {
      for (const ctx of context) {
        const base = this.extractBaseFromContext(ctx);
        if (base) return base;
      }
    } else if (typeof context === 'object' && context !== null) {
      // Look for @base in the context
      if (context['@base']) {
        return context['@base'];
      }
      
      // Also check for base URL patterns in context values
      for (const [key, value] of Object.entries(context)) {
        if (typeof value === 'string' && value.startsWith('http') && value.endsWith('/')) {
          // This might be a base URL
          console.log(`🔍 Found potential base URL in context['${key}']: ${value}`);
        }
      }
    }
    
    return null;
  }

  // Export functions
  async copyToClipboard() {
    if (!this.currentProcessedData) return;
    
    try {
      const displayData = this.jsonRenderer.filterHiddenFields(this.currentProcessedData);
      const jsonString = JSON.stringify(displayData, null, 2);
      await navigator.clipboard.writeText(jsonString);
      
      const btn = document.getElementById('copyBtn');
      const originalText = btn.textContent;
      btn.textContent = 'Copied!';
      btn.style.backgroundColor = 'var(--success-color)';
      
      setTimeout(() => {
        btn.textContent = originalText;
        btn.style.backgroundColor = '';
      }, 2000);
    } catch (error) {
      this.fallbackCopy();
    }
  }

  fallbackCopy() {
    const displayData = this.jsonRenderer.filterHiddenFields(this.currentProcessedData);
    const jsonString = JSON.stringify(displayData, null, 2);
    const textArea = document.createElement('textarea');
    textArea.value = jsonString;
    document.body.appendChild(textArea);
    textArea.select();
    document.execCommand('copy');
    document.body.removeChild(textArea);
    
    const btn = document.getElementById('copyBtn');
    const originalText = btn.textContent;
    btn.textContent = 'Copied!';
    setTimeout(() => {
      btn.textContent = originalText;
    }, 2000);
  }

  downloadJson() {
    if (!this.currentProcessedData) return;
    
    const displayData = this.jsonRenderer.filterHiddenFields(this.currentProcessedData);
    const jsonString = JSON.stringify(displayData, null, 2);
    const blob = new Blob([jsonString], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    a.download = `cmipld-data-${this.isExpanded ? 'expanded' : 'compacted'}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  // Utility methods
  clearData() {
    this.documentLoader.clear();
    this.jsonldProcessor.clear();
    this.currentRawData = null;
    this.currentProcessedData = null;
    this.resolvedContext = {};
  }

  // Ensure linked fields are present and resolved in compacted data
  ensureLinkedFieldsPresent(compactedData, expandedData) {
    if (!this.referenceManager.linkProperties || this.referenceManager.linkProperties.size === 0) {
      return compactedData;
    }

    console.log('🔗 Resolving linked fields in compacted data');
    
    // Helper function to resolve and add linked fields to an object
    const resolveLinkedFieldsInObject = (obj) => {
      if (typeof obj !== 'object' || obj === null || Array.isArray(obj)) {
        return obj;
      }
      
      const result = { ...obj };
      
      // For each linked property defined in the context
      for (const linkedProp of this.referenceManager.linkProperties) {
        // Check if this property exists and needs resolution
        if (result[linkedProp] !== undefined) {
          const value = result[linkedProp];
          
          if (typeof value === 'string') {
            // Single reference - resolve it
            const resolvedEntity = this.resolveLinkedReference(value);
            if (resolvedEntity) {
              console.log(`🔗 Resolved linked field '${linkedProp}': ${value}`);
              result[linkedProp] = resolvedEntity;
            }
          } else if (Array.isArray(value)) {
            // Array of references - resolve each
            const resolved = value.map(item => {
              if (typeof item === 'string') {
                const resolvedEntity = this.resolveLinkedReference(item);
                return resolvedEntity || item;
              }
              return item;
            });
            console.log(`🔗 Resolved linked field array '${linkedProp}':`, value);
            result[linkedProp] = resolved;
          } else if (typeof value === 'object' && value['@id']) {
            // Object with @id - resolve it
            const resolvedEntity = this.resolveLinkedReference(value['@id']);
            if (resolvedEntity) {
              console.log(`🔗 Resolved linked field object '${linkedProp}': ${value['@id']}`);
              result[linkedProp] = { ...resolvedEntity, ...value };
            }
          }
        } else {
          // Field is missing - try to find it in the original data
          const originalValue = this.findOriginalLinkedValue(obj, linkedProp);
          if (originalValue !== undefined) {
            // Resolve the original value
            if (typeof originalValue === 'string') {
              const resolvedEntity = this.resolveLinkedReference(originalValue);
              if (resolvedEntity) {
                console.log(`🔗 Added and resolved missing linked field '${linkedProp}': ${originalValue}`);
                result[linkedProp] = resolvedEntity;
              } else {
                result[linkedProp] = originalValue;
              }
            } else if (Array.isArray(originalValue)) {
              const resolved = originalValue.map(item => {
                if (typeof item === 'string') {
                  const resolvedEntity = this.resolveLinkedReference(item);
                  return resolvedEntity || item;
                }
                return item;
              });
              console.log(`🔗 Added and resolved missing linked field array '${linkedProp}'`);
              result[linkedProp] = resolved;
            } else {
              result[linkedProp] = originalValue;
            }
          }
        }
      }
      
      return result;
    };
    
    // Process the data structure
    if (Array.isArray(compactedData)) {
      return compactedData.map(item => resolveLinkedFieldsInObject(item));
    } else if (compactedData['@graph'] && Array.isArray(compactedData['@graph'])) {
      return {
        ...compactedData,
        '@graph': compactedData['@graph'].map(item => resolveLinkedFieldsInObject(item))
      };
    } else {
      return resolveLinkedFieldsInObject(compactedData);
    }
  }

  // Resolve a linked reference to its full entity data
  resolveLinkedReference(reference) {
    if (!reference || typeof reference !== 'string') {
      return null;
    }
    
    // Try to get from the entity index
    const entity = this.jsonldProcessor.getEntityFromIndex(reference, CONFIG.prefixMapping);
    if (entity) {
      // Return a compacted version of the entity
      const compacted = this.compactEntity(entity);
      return compacted;
    }
    
    // Try to resolve the reference
    const resolvedRef = Utils.resolvePrefix(reference, CONFIG.prefixMapping);
    
    // Check if we have this document loaded
    if (this.documentLoader.loadedDocuments.has(resolvedRef)) {
      const doc = this.documentLoader.loadedDocuments.get(resolvedRef);
      return this.compactEntity(doc);
    }
    
    console.warn(`⚠️ Could not resolve linked reference: ${reference}`);
    return null;
  }

  // Compact an entity for display
  compactEntity(entity) {
    if (!entity) return null;
    
    // If it's already compacted, return as is
    if (!Array.isArray(entity) && !entity['@type'] && entity.type) {
      return entity;
    }
    
    // Simple compaction - just use the context mapping
    const compacted = {};
    
    for (const [key, value] of Object.entries(entity)) {
      // Find the compact form of the key
      let compactKey = key;
      
      // Check if this is an expanded URI that maps to a compact name
      if (this.referenceManager.expandedToCompactMap && 
          this.referenceManager.expandedToCompactMap.has(key)) {
        compactKey = this.referenceManager.expandedToCompactMap.get(key);
      } else if (key === '@type') {
        compactKey = 'type';
      } else if (key === '@id') {
        compactKey = 'id';
      }
      
      // Don't include @context in the compacted entity
      if (key !== '@context') {
        compacted[compactKey] = value;
      }
    }
    
    return compacted;
  }

  // Find the original object from raw data
  findOriginalObject(obj) {
    const objId = obj['@id'] || obj['id'];
    if (!objId || !this.currentRawData) {
      return null;
    }
    
    const findInData = (data, id) => {
      if (typeof data !== 'object' || data === null) {
        return null;
      }
      
      if (Array.isArray(data)) {
        for (const item of data) {
          const found = findInData(item, id);
          if (found) return found;
        }
      } else {
        // Check if this is the object we're looking for
        if (data['@id'] === id || data['id'] === id) {
          return data;
        }
        
        // Search in @graph
        if (data['@graph']) {
          const found = findInData(data['@graph'], id);
          if (found) return found;
        }
        
        // Search in other properties
        for (const value of Object.values(data)) {
          if (typeof value === 'object') {
            const found = findInData(value, id);
            if (found) return found;
          }
        }
      }
      
      return null;
    };
    
    return findInData(this.currentRawData, objId);
  }

  // Find the original linked value for an object
  findOriginalLinkedValue(obj, linkedProp) {
    // Get the object's ID to find it in the original data
    const objId = obj['@id'] || obj['id'];
    
    if (!objId || !this.currentRawData) {
      return undefined;
    }
    
    // Search for this object in the original data
    const findInData = (data, id) => {
      if (typeof data !== 'object' || data === null) {
        return undefined;
      }
      
      if (Array.isArray(data)) {
        for (const item of data) {
          const found = findInData(item, id);
          if (found !== undefined) return found;
        }
      } else {
        // Check if this is the object we're looking for
        if ((data['@id'] === id || data['id'] === id) && data[linkedProp] !== undefined) {
          return data[linkedProp];
        }
        
        // Search in @graph
        if (data['@graph']) {
          return findInData(data['@graph'], id);
        }
        
        // Search in other properties
        for (const value of Object.values(data)) {
          if (typeof value === 'object') {
            const found = findInData(value, id);
            if (found !== undefined) return found;
          }
        }
      }
      
      return undefined;
    };
    
    return findInData(this.currentRawData, objId);
  }
}

// Initialize the viewer when the page loads
document.addEventListener('DOMContentLoaded', () => {
  new CMIPLDViewer();
});
