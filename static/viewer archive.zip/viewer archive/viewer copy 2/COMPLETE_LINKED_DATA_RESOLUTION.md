# Complete Linked Data Loading and Substitution Fix

## Overview
The complete solution ensures that when JSON-LD data contains linked fields (marked with `@type: @id`), the system:
1. Expands values to `@id` objects during JSON-LD expansion
2. Downloads the referenced documents
3. Substitutes the references with the actual entity data

## Implementation Flow

### 1. Context Processing
When a context defines a field with `@type: @id`:
```json
{
  "@context": {
    "@base": "https://example.org/",
    "activity": {"@type": "@id"}
  }
}
```

### 2. JSON-LD Expansion
The `manuallyExpandObject` method detects linked fields and expands values:
- `"activity": ["cmip"]` becomes `"activity": [{"@id": "https://example.org/cmip"}]`

### 3. Reference Collection and Document Loading
The enhanced `loadLinkedDocuments` method:
- Expands the data to find all `@id` references
- Collects references from objects with only `@id` (or `@id` + `@type`)
- Downloads each referenced document
- Recursively loads linked documents based on depth

### 4. Entity Indexing
Downloaded documents are indexed so entities can be looked up by their `@id`

### 5. Reference Resolution
The `processLinkedFields` method:
- Detects objects with only `@id` property
- Looks up the entity in the index
- Replaces the reference with the full entity data

## Key Components

### Enhanced loadLinkedDocuments:
```javascript
async loadLinkedDocuments(data, baseUrl, depth) {
  // Expand the data to find @id references
  const expandedData = await this.jsonldProcessor.safeExpand(data);
  
  // Collect references from expanded data
  const refs = new Set();
  this.collectExpandedReferences(expandedData, refs);
  
  // Load each referenced document
  for (const ref of refs) {
    const linkedDoc = await this.documentLoader.fetchDocument(ref);
    // Recursive loading based on depth
  }
}
```

### collectExpandedReferences:
```javascript
collectExpandedReferences(data, refs) {
  if (data['@id'] && Object.keys(data).length <= 2) {
    // This is a reference that needs loading
    refs.add(data['@id']);
  }
  // Recursive collection
}
```

## Complete Example

Input:
```json
{
  "@context": {
    "@base": "https://wcrp-cmip.github.io/CMIP7-CVs/",
    "activity": {"@type": "@id"}
  },
  "id": "experiment1",
  "activity": ["cfmip", "deck"]
}
```

Processing steps:

1. **Expansion**:
   ```json
   {
     "@id": "experiment1",
     "https://...activity": [
       {"@id": "https://wcrp-cmip.github.io/CMIP7-CVs/cfmip"},
       {"@id": "https://wcrp-cmip.github.io/CMIP7-CVs/deck"}
     ]
   }
   ```

2. **Reference Collection**:
   - Found: `https://wcrp-cmip.github.io/CMIP7-CVs/cfmip`
   - Found: `https://wcrp-cmip.github.io/CMIP7-CVs/deck`

3. **Document Loading**:
   - Downloads cfmip.json
   - Downloads deck.json

4. **Entity Resolution**:
   ```json
   {
     "id": "experiment1",
     "activity": [
       {
         "@id": "https://wcrp-cmip.github.io/CMIP7-CVs/cfmip",
         "@type": "Activity",
         "name": "Cloud Feedback Model Intercomparison Project",
         "description": "..."
       },
       {
         "@id": "https://wcrp-cmip.github.io/CMIP7-CVs/deck",
         "@type": "Activity", 
         "name": "DECK",
         "description": "..."
       }
     ]
   }
   ```

## Console Output

```
🔗 Expanding linked array with 2 items
🔗 Expanding array item: "cfmip" -> {"@id": "https://wcrp-cmip.github.io/CMIP7-CVs/cfmip"}
🔗 Expanding array item: "deck" -> {"@id": "https://wcrp-cmip.github.io/CMIP7-CVs/deck"}
🔗 Loading linked documents at depth 2
🔗 Expanded data for reference collection
🔗 Found 2 total references to load
🔗 References: ["https://wcrp-cmip.github.io/CMIP7-CVs/cfmip", "https://wcrp-cmip.github.io/CMIP7-CVs/deck"]
🔗 Loading linked document: https://wcrp-cmip.github.io/CMIP7-CVs/cfmip
📦 Fetched linked document from https://wcrp-cmip.github.io/CMIP7-CVs/cfmip
🔗 Loading linked document: https://wcrp-cmip.github.io/CMIP7-CVs/deck
📦 Fetched linked document from https://wcrp-cmip.github.io/CMIP7-CVs/deck
📦 Indexed 2 entities from 3 documents
🔗 Substituting linked reference 'activity[0]': https://wcrp-cmip.github.io/CMIP7-CVs/cfmip -> entity
🔗 Substituting linked reference 'activity[1]': https://wcrp-cmip.github.io/CMIP7-CVs/deck -> entity
```

## Benefits

- Complete end-to-end linked data resolution
- Handles arrays of references properly
- Downloads only the documents that are actually referenced
- Recursive loading based on depth setting
- Clear logging shows each step of the process
- Works with @base and @vocab expansion
